
function appendToDisplay(value) {
    document.getElementById('display').value += value;
}

function clearDisplay() {
    document.getElementById('display').value = '';
}

function deleteLast() {
let display = document.getElementById('display');    
display.value = display.value.slice(0, -1)
}


function calculateResult() {
    let display = document.getElementById('display');
    let expression = display.value
    .replace(/x/g, '*')
    .replace(/÷/g, '/')
    .replace(/%/g, '/100');


    try {
        display.value = eval(expression);
    } catch (e) {
        display.value = 'Error';
    }
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Delete') {
     
       deleteLast();
    
    }
        
        
    
});